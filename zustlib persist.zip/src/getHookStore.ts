import { useContext } from 'react';

export function getHookStore(ctx: any) {

  return (instance = '') => {
    const storeWizard: any = useContext(ctx);

    if (!storeWizard) {
      throw new Error('Store is missing the provider');
    }

    if (instance === 'instance') {
      return storeWizard.instance;
    }

    return storeWizard.store();
  };
}
