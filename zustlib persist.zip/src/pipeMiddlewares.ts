import { create } from "zustand";
import { storePersist, storeDevTools, storeComputed, storeSubscribe } from './middlewares.js';
import { pipe } from './pipe.js';
//storeSubscribe

export const pipeMiddlewares = ({ nameStore, env, persist, computeState }) => pipe(
  // log,
  storeDevTools(nameStore, env),
  storePersist(nameStore, persist.state, persist.storage),
  storeComputed(nameStore, computeState),
  storeSubscribe,
  create
);
